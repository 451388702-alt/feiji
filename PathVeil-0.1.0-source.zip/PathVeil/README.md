# PathVeil 0.1.0 — LSPosed 源码预览版

基于 [XiaoTong6666/FuseHide v170](https://github.com/XiaoTong6666/FuseHide/releases/tag/v170) 的独立分支，增强按应用隐藏共享存储中的文件和目录。

**交付状态：源码已生成，独立 JVM 规则测试通过；完整 Android 构建尚未成功，无可安装 APK，也未进行真机验证。** 请勿将本源码 ZIP 当作 Magisk 或 LSPosed 安装包。

## 本分支新增或修改

- 独立应用名称 PathVeil、包名 `io.github.pathveil` 和图标；同步调整 Java/Kotlin、JNI 符号、Xposed 入口、广播和配置提供者身份。
- 单应用页面的「专属路径」和「同时应用全局规则」独立控制，可选择专属、全局或两者合并。
- 专属路径支持相对路径，以及 `/sdcard/`、`/storage/emulated/0/` 完整路径输入；自动去重、归一化重复分隔符。
- 无效路径显示行号并阻止本页保存；支持中文文件名和含空格文件名，不支持通配符、存储根目录、`..` 或其他存储卷。
- 显示配置路径预览，并提示共享 UID 与全局隐藏全部模式。预览是草稿，不代表运行时验证结果。
- 新安装不默认选择任何目标应用；移除上游示例应用专属规则。全局默认路径仍继承上游，但需要手动选择应用才应用。
- 使用独立 MediaProvider 配置快照文件，防止读取上游模块的旧快照。
- 默认构建仅生成 LSPosed APK，取消 Zygisk 编译和打包任务；旧 Zygisk 相关源码留作上游参考，不属于本分支交付功能。
- 包含上游锁定版本的 uihelper 源码，不依赖下载时的 main 分支，也不依赖 Git 提交历史生成版本号。

## 范围

沿用上游 MediaProvider/FUSE 路径过滤、目录枚举过滤和缓存处理。作用范围主要是主用户共享存储 `/storage/emulated/0`，不是任意系统目录、应用私有数据、设备信息或服务器功能。`Android/data`、`Android/obb` 保留上游特殊处理，不能保证与普通目录行为一致。

包名最终映射为 UID；同 UID 应用规则会合并，不能承诺对共享 UID 的两个应用独立隔离。本次未扩展多用户或外置存储支持。路径校验新增于单应用编辑器；上游高级全局文本编辑器保留原行为。

## 构建要求与当前阻塞

上游依赖版本保留：JDK 21、Gradle 9.7.1、AGP 9.4.1、Kotlin 2.4.20、Android SDK 37、NDK 30.0.15729638、CMake 3.22.1 或以上。需要可访问 Google Maven、Maven Central 和 Gradle 分发源。

用 Android Studio 打开此目录，配置 SDK 与 JDK 后运行：

```powershell
.\gradlew.bat :app:assembleDebug
```

成功后产物应位于 `app/build/outputs/apk/debug/app-debug.apk`。Debug 构建仅适合测试；对外分发应使用自己保管的正式签名密钥。

本次已用独立下载的 JDK 21 启动 Gradle，但在生成依赖目录访问器时发生 `GeneratedClassCompilationException`，内层为对 `gradle-dependency-management-9.7.1.jar` 的 `AccessDeniedException`。构建未到达 Android 源码编译阶段；当前机器亦未配置 Android SDK/NDK。不能据此断言 UI、native 或 APK 构建已通过。

## 编译成功后的验证步骤

1. 使用 Android 12+ 和支持现代 libxposed API 101/102 的 LSPosed 环境。普通旧版 LSPosed 不能直接假定兼容。
2. 先禁用原版 FuseHide 的 MediaProvider 作用域以及其 Zygisk 模块，重启；两个模块不要同时挂钩同一进程。
3. 安装自己编译的 APK，在 LSPosed 中启用，作用域选择设备上实际存在的 MediaProvider（系统或 Google 版本），重启。
4. 打开 PathVeil，选择目标应用，输入例如 `Download/private`；根据需要独立开启全局规则，保存并检查首页「已应用配置」。
5. 使用专门的测试目录，从目标应用验证目录枚举及直接打开；从未选择应用确认仍可见。检查冷启动、重启及关闭规则后的恢复。
6. 如出现文件访问或媒体服务异常，停用模块并重启。保留设备型号、系统、MediaProvider 和 LSPosed 版本用于定位。

## 已执行验证

- 编译实际 `AppPathRules.kt`，22 个输入场景通过：完整路径转换、Unicode、空格、去重、重复分隔符、行号与非法路径。
- 编译实际 `HideConfig.kt`、`HideConfigNativeBridge.java`、`AppRuleEditor.kt`，验证全局/专属开关独立、其他应用规则不变、无效输入保留旧配置和重复开关去重。
- 测试只用一个 Compose 标记注解替身，不替换生产规则逻辑，不加载 Android native 库。
- 静态检查资源 XML、入口、包名/JNI 一致性。没有真机验证、完整 Kotlin UI 编译或 native 编译结果。

独立检查脚本：

```powershell
.\tests\run-checks.ps1 -JdkHome C:\path\to\jdk21 -GradleLib C:\path\to\gradle\lib
```

## 开源来源

FuseHide 作者：XiaoTong6666。许可证：Apache-2.0，见 `LICENSE` 与 `NOTICE`。原始中英文说明保存在 `upstream/`，描述的是上游，不代表本分支已验证的功能。修改文件列表见 `MODIFIED_FILES.txt`。
