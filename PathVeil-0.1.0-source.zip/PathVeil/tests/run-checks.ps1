param([Parameter(Mandatory=$true)][string]$JdkHome, [Parameter(Mandatory=$true)][string]$GradleLib)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$testOutput = Join-Path $projectRoot 'build/standalone-checks'
New-Item -ItemType Directory -Force -Path $testOutput | Out-Null
$stdlib = Get-ChildItem -LiteralPath $GradleLib -Filter 'kotlin-stdlib-*.jar' | Select-Object -First 1 -ExpandProperty FullName
if (-not $stdlib) { throw 'Kotlin standard library missing from Gradle lib directory' }
$javaBin = Join-Path $JdkHome 'bin/java.exe'
$javacBin = Join-Path $JdkHome 'bin/javac.exe'
$sourceRoot = Join-Path $projectRoot 'app/src/main/java/io/github/pathveil'
& $javacBin -d $testOutput "$sourceRoot/config/HideConfigNativeBridge.java"
if ($LASTEXITCODE) { throw 'Native bridge declaration compile failed' }
& $javaBin -cp "$GradleLib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -classpath "$stdlib;$testOutput" -d $testOutput "$sourceRoot/config/AppPathRules.kt" "$sourceRoot/config/HideConfig.kt" "$sourceRoot/ui/adapter/AppRuleEditor.kt" "$PSScriptRoot/Immutable.kt" "$PSScriptRoot/AppPathRulesCheck.kt" "$PSScriptRoot/AppRuleEditorCheck.kt"
if ($LASTEXITCODE) { throw 'Kotlin compile failed' }
foreach ($entry in @('AppPathRulesCheckKt', 'AppRuleEditorCheckKt')) {
    & $javaBin -cp "$testOutput;$stdlib" "io.github.pathveil.tests.$entry"
    if ($LASTEXITCODE) { throw "Failed: $entry" }
}
