package io.github.pathveil.tests

import io.github.pathveil.config.HideConfig
import io.github.pathveil.config.PackageHideRule
import io.github.pathveil.ui.adapter.updatedConfigForPackageRule
import io.github.pathveil.ui.adapter.updatedGlobalInheritance

fun main() {
    val other = PackageHideRule("other.app", listOf("Pictures"), emptyList())
    val base = HideConfig(false, emptyList(), listOf("global"), emptyList(), listOf("target.app"), listOf(other))
    val custom = updatedConfigForPackageRule(base, "target.app", true, "/sdcard/Download/private")
    check(custom.hiddenPackages == base.hiddenPackages)
    check(custom.packageRules.first() == other)
    check(custom.packageRules.last().hiddenRelativePaths == listOf("Download/private"))
    val onlyCustom = updatedGlobalInheritance(custom, "target.app", false)
    check(onlyCustom.hiddenPackages.isEmpty() && onlyCustom.packageRules == custom.packageRules)
    val disabled = updatedConfigForPackageRule(custom, "target.app", false, "Download/private")
    check(disabled.hiddenPackages == base.hiddenPackages && disabled.packageRules == listOf(other))
    check(updatedConfigForPackageRule(custom, "target.app", true, "../bad") == custom)
    val twice = updatedGlobalInheritance(updatedGlobalInheritance(onlyCustom, "target.app", true), "target.app", true)
    check(twice.hiddenPackages == listOf("target.app"))
    check(updatedConfigForPackageRule(base, "target.app", true, "").packageRules == listOf(other))
    println("PASS: independent global/custom rules, disable behavior, other-app isolation, invalid edit preservation and deduplication")
}
