package io.github.pathveil.tests

import io.github.pathveil.config.parseAppPathRules

fun main() {
    val equivalent = parseAppPathRules("Download/private\n/sdcard/Download/private\n/storage/emulated/0/Download/private/")
    check(equivalent.isValid && equivalent.relativePaths == listOf("Download/private"))
    val unicode = parseAppPathRules("Pictures/私人照片\nDocuments/a file.txt\n.hidden")
    check(unicode.isValid && unicode.rootEntries == listOf(".hidden") && unicode.relativePaths.size == 2)
    check(parseAppPathRules("Download//private///").paths == listOf("Download/private"))
    check(parseAppPathRules("|Download/private").paths == listOf("Download/private"))
    check(parseAppPathRules("  \n").paths.isEmpty())
    listOf("/sdcard", "/storage/emulated/0/", "/data/local", "/sdcard-other/x",
        "/storage/emulated/10/a", "../x", "a/../b", "a/./b", "*", "a?b", "[some.app]",
        "a\\b", "content://media/a", "a\u0000b", "a\tb").forEach {
        check(!parseAppPathRules(it).isValid) { "Unexpectedly accepted: $it" }
    }
    check(parseAppPathRules("Download/ok\n\n../bad").errors.single().line == 3)
    check(parseAppPathRules("foo\nfoobar\nfoo/file.txt").paths.toSet() == setOf("foo", "foobar", "foo/file.txt"))
    println("PASS: 22 path-input scenarios, including normalization, Unicode, deduplication and invalid inputs")
}
