// Standalone JVM test shim for the Compose marker annotation only.
// Production model and rule logic are compiled unchanged.
package androidx.compose.runtime
annotation class Immutable
