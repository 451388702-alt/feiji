// Modified for PathVeil: independent module identity and configuration.
/*
 * Copyright (C) 2026 XiaoTong6666
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("ktlint:standard:function-naming")

package io.github.pathveil.ui.feature.config.appdetail

import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import io.github.pathveil.config.parseAppPathRules
import io.github.pathveil.ui.adapter.updatedGlobalInheritance
import io.github.xiaotong6666.uihelper.adaptive.InfoBanner
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.pathveil.R
import io.github.pathveil.ui.adapter.appSpecificTargetsText
import io.github.pathveil.ui.adapter.updatedConfigForPackageRule
import io.github.pathveil.ui.core.model.ConfigCallbacks
import io.github.pathveil.ui.core.model.ConfigUiState
import io.github.pathveil.ui.feature.config.appdetail.widgets.AppConfigInfoCard
import io.github.pathveil.ui.feature.config.appdetail.widgets.AppConfigPageScaffold
import io.github.pathveil.ui.feature.config.appdetail.widgets.AppConfigToggleCard
import io.github.pathveil.ui.feature.config.appdetail.widgets.ConfigDetailPageBody
import io.github.pathveil.ui.feature.config.applist.AppListViewModel
import io.github.xiaotong6666.uihelper.adaptive.DetailGroup
import io.github.xiaotong6666.uihelper.adaptive.SettingsTextAreaItem
import io.github.xiaotong6666.uihelper.extensions.androidapp.AppIconImage
import io.github.xiaotong6666.uihelper.extensions.androidapp.AppIconVariant

@Composable
fun AppConfigPage(
    packageName: String,
    state: ConfigUiState,
    callbacks: ConfigCallbacks,
    appListViewModel: AppListViewModel,
    onBack: () -> Unit,
    onSave: () -> Unit,
) {
    val view = LocalView.current
    val context = LocalContext.current
    val uiState by appListViewModel.uiState.collectAsStateWithLifecycle()
    val appInfo = remember(uiState.groupedApps, packageName) {
        uiState.groupedApps.asSequence()
            .flatMap { it.apps.asSequence() }
            .find { it.packageName == packageName }
    }

    val isHiddenGlobally = state.currentHideConfig.hiddenPackages.contains(packageName)
    val specificRule = state.currentHideConfig.packageRules.find { it.packageName == packageName }
    val isHiddenSpecifically = specificRule != null
    var isEnabled by rememberSaveable(packageName) { mutableStateOf(isHiddenSpecifically) }

    val specificTargetsText = appSpecificTargetsText(state.currentHideConfig, packageName)
    var specificTargetsDraft by rememberSaveable(packageName) { mutableStateOf(specificTargetsText) }
    val topBarTitle = appInfo?.label ?: packageName
    val parsedDraft = remember(specificTargetsDraft) { parseAppPathRules(specificTargetsDraft) }
    val errorMessage = when {
        isEnabled && !parsedDraft.isValid -> stringResource(R.string.pv_invalid_paths, parsedDraft.errors.joinToString { it.line.toString() })
        isEnabled && parsedDraft.paths.isEmpty() -> stringResource(R.string.pv_empty_paths)
        else -> null
    }
    val configuredPaths = buildList {
        if (isHiddenGlobally) {
            addAll(state.currentHideConfig.hiddenRootEntryNames)
            addAll(state.currentHideConfig.hiddenRelativePaths)
        }
        if (isEnabled && parsedDraft.isValid) addAll(parsedDraft.paths)
    }.distinct()
    val preview = configuredPaths.joinToString("\n") { "/storage/emulated/0/$it" }


    AppConfigPageScaffold(
        title = topBarTitle,
        onBack = onBack,
        onSave = {
            if (errorMessage != null) Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
            else onSave()
        },
    ) { contentPadding, scrollModifier ->
        ConfigDetailPageBody(
            contentPadding = contentPadding,
            scrollModifier = scrollModifier.fillMaxSize(),
        ) {
            DetailGroup {
                item {
                    AppConfigInfoCard(
                        label = appInfo?.label ?: packageName,
                        packageName = appInfo?.packageName ?: packageName,
                        versionName = appInfo?.packageInfo?.versionName.orEmpty(),
                        versionCode = appInfo?.packageInfo?.longVersionCode ?: 0L,
                        uid = appInfo?.uid ?: -1,
                        appIcon = appInfo?.let {
                            {
                                AppIconImage(
                                    applicationInfo = it.applicationInfo,
                                    label = it.label,
                                    variant = AppIconVariant.Detail,
                                )
                            }
                        },
                    )
                }
            }
            if (errorMessage != null) InfoBanner(message = errorMessage)
            InfoBanner(message = stringResource(R.string.pv_preview, preview.ifEmpty { "—" }))
            if (isHiddenGlobally && state.currentHideConfig.enableHideAllRootEntries) {
                InfoBanner(message = stringResource(R.string.pv_hide_all_notice))
            }
            InfoBanner(message = stringResource(R.string.pv_uid_notice))
            DetailGroup {
                item {
                    AppConfigToggleCard(
                        checked = isEnabled,
                        title = stringResource(R.string.pv_specific_title),
                        description = stringResource(R.string.pv_specific_desc),
                        onToggle = {
                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            callbacks.onConfigUpdate(
                                updatedConfigForPackageRule(
                                    currentConfig = state.currentHideConfig,
                                    packageName = packageName,
                                    enabled = !isEnabled,
                                    targetsText = specificTargetsDraft,
                                ),
                            )
                            isEnabled = !isEnabled
                        },
                    )
                }
                item {
                    AppConfigToggleCard(
                        checked = isHiddenGlobally,
                        title = stringResource(R.string.pv_global_title),
                        description = stringResource(R.string.pv_global_desc),
                        onToggle = {
                            callbacks.onConfigUpdate(updatedGlobalInheritance(
                                state.currentHideConfig, packageName, !isHiddenGlobally,
                            ))
                        },
                    )
                }
                item {
                    SettingsTextAreaItem(
                        value = specificTargetsDraft,
                        onValueChange = { newText ->
                            specificTargetsDraft = newText
                            callbacks.onConfigUpdate(
                                updatedConfigForPackageRule(
                                    currentConfig = state.currentHideConfig,
                                    packageName = packageName,
                                    enabled = isEnabled,
                                    targetsText = newText,
                                ),
                            )
                        },
                        title = stringResource(R.string.subdirectory_title),
                        description = stringResource(R.string.pv_path_help),
                    )
                }
            }
        }
    }
}
