// PathVeil additions, 2026. Licensed under Apache-2.0.
package io.github.pathveil.ui.adapter

import io.github.pathveil.config.HideConfig
import io.github.pathveil.config.PackageHideRule
import io.github.pathveil.config.parseAppPathRules

/** Edits only the app-specific rule. Global inheritance is an independent choice. */
fun updatedConfigForPackageRule(
    currentConfig: HideConfig,
    packageName: String,
    enabled: Boolean,
    targetsText: String,
): HideConfig {
    val parsed = parseAppPathRules(targetsText)
    if (enabled && !parsed.isValid) return currentConfig
    val rules = currentConfig.packageRules.filterNot { it.packageName == packageName }.toMutableList()
    if (enabled && parsed.paths.isNotEmpty()) {
        rules += PackageHideRule(packageName, parsed.rootEntries, parsed.relativePaths)
    }
    return currentConfig.copy(packageRules = rules)
}

fun updatedGlobalInheritance(config: HideConfig, packageName: String, inherit: Boolean): HideConfig =
    config.copy(hiddenPackages = (config.hiddenPackages.filterNot { it == packageName } +
        if (inherit) listOf(packageName) else emptyList()).distinct())
