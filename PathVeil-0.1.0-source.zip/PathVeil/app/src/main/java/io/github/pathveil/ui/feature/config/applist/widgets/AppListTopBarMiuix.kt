// Modified for PathVeil: independent module identity and configuration.
/*
 * Copyright (C) 2026 XiaoTong6666
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("ktlint:standard:function-naming")

package io.github.pathveil.ui.feature.config.applist.widgets

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme

@Composable
fun AppListTopBarMiuix(
    title: String,
    onNavigateToGlobalConfig: () -> Unit,
    actionContentDescription: String,
) {
    TopAppBar(
        color = colorScheme.surface,
        title = title,
        actions = {
            IconButton(onClick = onNavigateToGlobalConfig) {
                androidx.compose.material3.Icon(
                    imageVector = Icons.Default.Settings,
                    tint = colorScheme.onSurface,
                    contentDescription = actionContentDescription,
                )
            }
        },
    )
}
