// PathVeil additions, 2026. Licensed under Apache-2.0.
package io.github.pathveil.config

data class AppPathError(val line: Int, val reason: String)

data class AppPathRules(
    val rootEntries: List<String>,
    val relativePaths: List<String>,
    val errors: List<AppPathError>,
) {
    val isValid: Boolean get() = errors.isEmpty()
    val paths: List<String> get() = rootEntries + relativePaths
}

/** Literal paths under primary shared storage only; never interpret shell patterns. */
fun parseAppPathRules(text: String): AppPathRules {
    val paths = linkedSetOf<String>()
    val errors = mutableListOf<AppPathError>()
    text.lineSequence().forEachIndexed { index, raw ->
        var path = raw.trim().removePrefix("|")
        if (path.isEmpty()) return@forEachIndexed
        val storageRoot = listOf("/storage/emulated/0", "/sdcard").firstOrNull {
            path == it || path.startsWith("$it/")
        }
        if (storageRoot != null) path = path.removePrefix(storageRoot).trimStart('/')
        val reason = when {
            path.isEmpty() -> "root"
            path.startsWith('/') -> "absolute"
            path.any { it.code < 32 || it.code == 127 } -> "control"
            path.any { it in "\\*?[]|:" } -> "syntax"
            path.split('/').any { it == "." || it == ".." } -> "traversal"
            else -> null
        }
        if (reason != null) {
            errors += AppPathError(index + 1, reason)
        } else {
            val normalized = path.split('/').filter { it.isNotEmpty() }.joinToString("/")
            if (normalized.isEmpty()) errors += AppPathError(index + 1, "root")
            else paths += normalized
        }
    }
    return AppPathRules(paths.filterNot { '/' in it }, paths.filter { '/' in it }, errors)
}
