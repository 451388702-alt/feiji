// Modified for PathVeil: independent module identity and configuration.
/*
 * Copyright (C) 2026 XiaoTong6666
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("ktlint:standard:function-naming")

package io.github.pathveil.ui.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import io.github.pathveil.R
import io.github.pathveil.ui.core.model.ConfigCallbacks
import io.github.pathveil.ui.core.model.ConfigUiState
import io.github.pathveil.ui.core.model.DebugCallbacks
import io.github.pathveil.ui.core.model.DebugUiState
import io.github.pathveil.ui.core.model.HideConfigDiff
import io.github.pathveil.ui.core.model.HomeCallbacks
import io.github.pathveil.ui.core.model.HookStatusUiState
import io.github.pathveil.ui.core.model.SettingsCallbacks
import io.github.pathveil.ui.core.model.SettingsUiState
import io.github.pathveil.ui.feature.config.ConfigPage
import io.github.pathveil.ui.feature.config.applist.AppListViewModel
import io.github.pathveil.ui.feature.debug.DebugPage
import io.github.pathveil.ui.feature.home.HomePage
import io.github.pathveil.ui.feature.settings.SettingsPage
import io.github.xiaotong6666.uihelper.chrome.AdaptiveNavigationShell
import io.github.xiaotong6666.uihelper.chrome.NavigationShellAction
import io.github.xiaotong6666.uihelper.chrome.NavigationShellItem
import io.github.xiaotong6666.uihelper.mode.UiMode

@Composable
fun MainPage(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    hookStatus: HookStatusUiState,
    configState: ConfigUiState,
    debugState: DebugUiState,
    homeCallbacks: HomeCallbacks,
    configCallbacks: ConfigCallbacks,
    appListViewModel: AppListViewModel,
    onOpenGlobalConfig: () -> Unit,
    onOpenAppConfig: (String) -> Unit,
    debugCallbacks: DebugCallbacks,
    settingsState: SettingsUiState,
    settingsCallbacks: SettingsCallbacks,
) {
    val homeTitle = stringResource(R.string.nav_home)
    val appTitle = stringResource(R.string.app_name)
    val configTitle = stringResource(R.string.nav_config)
    val probeTitle = stringResource(R.string.nav_probe)
    val settingsTitle = stringResource(R.string.nav_settings)
    val globalConfigTitle = stringResource(R.string.global_hide_config_title)
    val pageItems = remember(homeTitle, appTitle, configTitle, probeTitle, settingsTitle, globalConfigTitle, onOpenGlobalConfig) {
        listOf(
            NavigationShellItem(
                title = homeTitle,
                topBarTitle = appTitle,
                icon = Icons.Outlined.Home,
                selectedIcon = Icons.Filled.Home,
            ),
            NavigationShellItem(
                title = configTitle,
                icon = Icons.Outlined.Tune,
                selectedIcon = Icons.Filled.Tune,
                action = NavigationShellAction(
                    icon = Icons.Default.Settings,
                    contentDescription = globalConfigTitle,
                    onClick = onOpenGlobalConfig,
                ),
            ),
            NavigationShellItem(
                title = probeTitle,
                icon = Icons.Outlined.Search,
                selectedIcon = Icons.Filled.Search,
            ),
            NavigationShellItem(
                title = settingsTitle,
                icon = Icons.Outlined.Settings,
                selectedIcon = Icons.Filled.Settings,
            ),
        )
    }

    LaunchedEffect(appListViewModel) {
        withFrameNanos { }
        appListViewModel.loadAppList().join()
    }

    AdaptiveNavigationShell(
        items = pageItems,
        selectedIndex = selectedTab,
        onSelectedIndexChange = onTabSelected,
        enableMiuixBlur = settingsState.enableMiuixBlur,
        enableMiuixFloatingBottomBar = settingsState.enableMiuixFloatingBottomBar,
    ) { page, contentPadding, isCurrentPage, pageModifier ->
        when (page) {
            0 -> HomePage(
                hookStatus = hookStatus,
                configState = configState,
                callbacks = homeCallbacks,
                contentPadding = contentPadding,
                isCurrentPage = isCurrentPage,
                modifier = pageModifier,
            )

            1 -> ConfigPage(
                hookStatus = hookStatus,
                state = configState,
                callbacks = configCallbacks,
                contentPadding = contentPadding,
                isCurrentPage = isCurrentPage,
                modifier = pageModifier,
                appListViewModel = appListViewModel,
                onOpenGlobalConfig = onOpenGlobalConfig,
                onOpenAppConfig = onOpenAppConfig,
            )

            2 -> DebugPage(
                state = debugState,
                callbacks = debugCallbacks,
                contentPadding = contentPadding,
                isCurrentPage = isCurrentPage,
                modifier = pageModifier,
            )

            else -> SettingsPage(
                state = settingsState,
                callbacks = settingsCallbacks,
                contentPadding = contentPadding,
                isCurrentPage = isCurrentPage,
                modifier = pageModifier,
            )
        }
    }
}

@Preview(showBackground = true, device = "id:pixel_9_pro")
@Composable
private fun PreviewMainPage() {
    io.github.pathveil.ui.theme.FuseHideTheme {
        MainPage(
            selectedTab = 0,
            onTabSelected = {},
            hookStatus = HookStatusUiState(
                infoText = "Kernel: 6.1.118\nDevice: Fuxi\nSDK: 3600000",
                statusText = "Hooked: com.example.app (1234)",
                isHooked = true,
                backend = io.github.pathveil.ui.core.model.HookBackend.Xposed,
                hookedPackage = "com.example.app",
                hookedPid = 1234,
                hookCheckCompleted = true,
            ),
            configState = ConfigUiState(
                configStatusText = "The saved hidden configuration has been loaded.",
                lastAckTokenText = "-",
                lastAckResultText = "-",
                lastApplyTimeText = "-",
                draftVsAppliedDiff = HideConfigDiff(
                    hasDifferences = false,
                    summary = "None",
                    details = "",
                ),
                appliedConfigSnapshotText = "Current native config snapshot...",
                appliedConfigQueryPending = false,
                hasAppliedConfig = true,
                highlightConfigResults = false,
                configResultsScrollToken = 0,
                currentHideConfig = io.github.pathveil.config.HideConfigDefaults.value,
            ),
            debugState = DebugUiState(
                pathText = "/storage/emulated/0/Android",
                pathText2 = "",
                outputText = "Stat /storage/emulated/0/Android -> OK",
            ),
            homeCallbacks = HomeCallbacks(
                onStatusClick = {},
                onConfigSyncClick = {},
            ),
            configCallbacks = ConfigCallbacks(
                onStatusClick = {},
                onConfigUpdate = {},
                onApplyConfigClick = {},
                onResetConfigClick = {},
            ),
            appListViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
            onOpenGlobalConfig = {},
            onOpenAppConfig = {},
            debugCallbacks = DebugCallbacks(
                onStatusClick = {},
                onPathChanged = {},
                onPath2Changed = {},
                onStatClick = {},
                onAccessClick = {},
                onListClick = {},
                onOpenClick = {},
                onGetConClick = {},
                onCreateClick = {},
                onMkdirClick = {},
                onMoveClick = {},
                onRmdirClick = {},
                onUnlinkClick = {},
                onAllPkgClick = {},
                onInsertZwjClick = {},
                onClearClick = {},
                onResetClick = {},
                onCopyAllClick = {},
                onSelfDataClick = {},
            ),
            settingsState = SettingsUiState(
                uiMode = UiMode.Miuix,
                enableMiuixBlur = false,
                enableMiuixFloatingBottomBar = false,
            ),
            settingsCallbacks = SettingsCallbacks(
                onToggleUiMode = {},
                onToggleMiuixBlur = {},
                onToggleMiuixFloatingBottomBar = {},
            ),
        )
    }
}
